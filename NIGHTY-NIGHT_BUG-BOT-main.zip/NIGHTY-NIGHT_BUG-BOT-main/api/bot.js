export default async function handler(req, res) {
  // Your bot code logic here
  res.status(200).json({ message: 'Bot is running' });
}

