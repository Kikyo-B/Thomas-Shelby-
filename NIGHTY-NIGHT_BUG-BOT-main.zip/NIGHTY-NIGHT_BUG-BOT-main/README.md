<h1 align="center"> Created By THOMAS SHELBY</h1>

<p align="center">
<img src="https://telegra.ph/file/92b9daeb086890bd7b7dc.jpg" width="360" height="360"/>
</p>

<p align="center">
<a href="https://wa.me//2348087915719"><img title="Author" src="https://img.shields.io/badge/Dagger-Bot?style=for-the-badge&logo=whatsapp"></a>
<p/>

</a>
</p>  
<h2 align="center">Guide For Those Of You Who Use Termux</h2>

## Install Several Packages And Run Bots

```csharp
> git clone https://github.com/Kiyo-A/THOMAS SHELBY MD💀
> apt-get update -y
> apt-get upgrade -y
> apt-get install -y git
> sh wibu.sh
````

<h2 align="center">Guide For Panel Users</h2>

## 🖥 Go to panel and upload this Sc.

 📝 After that, extract or move it to a directory (container).

 ⌨ Use the following code to move into a container: "../"

 🖨 Then go to the console and press Start, and you will get a Qr code that will be linked to WhatsApp

<h2 align="center">Features</h2>

## How to deploy to heroku

```csharp
🦠| .You need to scan and get session using pair code
🦠| .Upload session to { Daggerses }
🦠| .Go to [Heroku](heroku.com) Login 
🦠| .Create a new app
🦠| .Add the Build packs Below 
🦠| .👇👇
```

# DEPLOY BY SESSION ID or creds.json (pair-code)


<a href="https://replit.com/@okoyee2004/Classic-Pairing-12#main.sh"><img src="https://i.ibb.co/5BGSVZw/pair-code-btn-zusyco.png" alt="PAIR-CODE" border="2" width="170" height="41" ></a> CLICK HERE 


# RENDER DEPLOYMENT༒

★ Register To Render 
    <br>
<a href='https://dashboard.render.com/register' target="_blank"><img alt='Render' src='https://img.shields.io/badge/CREATE-h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>

★ Now Deploy
    <br>
<a href='https://dashboard.render.com/select-repo?type=web' target="_blank"><img alt='DEPLOY' src='https://img.shields.io/badge/DEPLOY -h?color=black&style=for-the-badge&logo=render' width="96.35" height="28"/></a></p>
## Heroku Buildpack
```bash
heroku/nodejs
https://github.com/jonathanong/heroku-buildpack-ffmpeg-latest
https://github.com/clhuang/heroku-buildpack-webp-binaries.git
```





## Contact Me
  
* [Whatsapp Direct Message](https://Wa.me/2348087915719?text=Boss%20NIGHTＳ%20my%20name%20is___%20and%20I've%20saved%20your%20contact%20you%20should%20please%20save%20mine%20too%20%20✅)
—————————————————————
┈╭━━━━━━━━━━━╮┈ ┈┃╭━━━╮┊╭━━━╮┃┈ ╭┫┃┈▇┈┃┊┃┈▇┈┃┣╮ ┃┃╰━━━╯┊╰━━━╯┃┃ ╰┫╭━╮╰━━━╯╭━╮┣╯ ┈┃┃┣┳┳┳┳┳┳┳┫┃┃┈ ┈┃┃╰┻┻┻┻┻┻┻╯┃┃┈ ┈╰━━━━━━━━━━━╯┈
*`Y'ALL NIGGA`*
.……..… /´¯/)………....(\¯\.............
……….../….//……….. …\\….\. ........
………../….//………… ….\\….\. ......
…../´¯/…./´¯\………../¯ \….\¯`\.....
.././.../…./…./.|_……_|.\….\….\…\.\
(.(….(….(…./.)..)..(..(.\….)….)….).)
.\…………….\/../…..\....\/…………../
..\…………….. /……..\…………….../
…\…………... (...…….)……………..
—————————————————————
      *`NIGHT`*
  ,                         ︵
                        /'_/) 
                      /¯ ../ 
                    /'..../ 
                  /¯ ../ 
                /... ./
   ¸•´¯/´¯ /' ...'/´¯`•¸  
 /'.../... /.... /.... /¯\
('  (...´.(,.. ..(...../',    \
 \'.............. .......\'.    )      
   \'....................._.•´/
     \ ....................  /
       \ .................. |
         \  ............... |
           \............... |
             \ .............|
               \............|
                 \ .........|
                   \ .......|
                     \ .....|
                       \ ...|
                         \ .|
                           \\
                              \('-') 
   ,,                            |_|\
                                 | |
#   THOMAS SHELBY MD💀
 
 #   THOMAS SHELBY MD💀 
 
 